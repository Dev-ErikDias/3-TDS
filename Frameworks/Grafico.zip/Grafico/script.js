function grafico(){
    graf = document.getElementById("grafico");

    const months = ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun', 'Jul', 'Ago', 'Set', 'Out', 'Nov', 'Dez', 'Nig']

    const values = [20, 230, 410, 220, 300, 455, 600, 380, 150, 250, 500, 90, 50];
    const maxValue = Math.max(...values)

    months.forEach((month, index) => {
        let bar = document.createElement('div');
        let valor = document.createElement('div')
        let maxwidth = window.innerWidth
        let width = maxwidth / values.length 
        console.log(width)
        valor.className = 'valor'

        valor.innerText  = values[index]

        bar.style.width = `${width}%`;
        bar.className = 'bar';
        let barHeight = (values[index] / maxValue) * 100;
        bar.style.height = `${barHeight}%`;
        bar.appendChild(valor);
        graf.appendChild(bar);
    })
}