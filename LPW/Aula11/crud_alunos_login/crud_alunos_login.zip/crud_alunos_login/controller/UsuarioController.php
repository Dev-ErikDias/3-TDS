<?php

require_once(__DIR__ . "/../dao/UsuarioDao.php");
require_once(__DIR__ . "/../service/UsuarioService.php");

class UsuarioController {

    private UsuarioDao $usuarioDao;
    private UsuarioService $usuarioService;

    public function __construct() {
        $this->usuarioDao = new UsuarioDao();    
        $this->usuarioService = new UsuarioService();        
    }

    public function logar(string $login, string $senha) {
        $erros = $this->usuarioService->validarDadosLogin($login, $senha);

        if(! empty($erros))
            return $erros;


        //Implementar validação de login
        $usuario = $this->usuarioDao->findByLoginSenha($login, $senha);

        if(!$usuario){
            return array("Login ou senha inválidos!");
        }

        //Salvar o usuário na sessão
        $this->usuarioService->salvarUsuario($usuario);
        
        //Retorna um array vazio para indicar que tudo deu certo
        return array();
    }

    public function deslogar(){
        $this->usuarioService->removerSessao();
    }

    public function verificarLogin(){
        return $this->usuarioService->verificarSessao();
    }


    public function getNomeUsuario(){
        return $this->usuarioService->nomeUsuario();
    }
}
