<?php
//Página para deslogar do sistema
include_once(__DIR__ . '/../../controller/UsuarioController.php');

$usuarioController = new UsuarioController();
$usuarioController->deslogar();

header("Location: " . BASE_URL . "/view/login/login.php");
