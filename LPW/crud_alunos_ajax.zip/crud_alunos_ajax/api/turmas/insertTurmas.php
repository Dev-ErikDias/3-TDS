<?php
include_once(__DIR__.'/../../controller/TurmaController.php');
include_once(__DIR__.'/../../model/Turma.php');
include_once(__DIR__.'/../../model/Disciplina.php');

$ano = is_numeric($_POST['ano']) ? $_POST['ano'] : null;
$idCurso = is_numeric($_POST['idCurso']) ? $_POST['idCurso'] : null;
$idDisciplina = is_numeric($_POST['idDisciplina']) ? $_POST['idDisciplina'] : null;

//echo "Ano: $ano \nIdCurso: $idCurso \nIdDisciplina: $idDisciplina";

$disciplina = new Disciplina($idDisciplina);

$turma = new Turma();
$turma->setAno($ano);
$turma->setDisciplina($disciplina);

print_r($turma);

//Chamar o controller para inserir a turma
?>