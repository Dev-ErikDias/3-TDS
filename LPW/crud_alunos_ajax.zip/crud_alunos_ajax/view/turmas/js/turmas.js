//Chamada inicial para carregar as disciplinas caso o curso já tenha sido selecionado
carregarDisciplinas();

//Função para carregar as disciplinas do curos (Forma assíncrona)
function carregarDisciplinas(){
    //Pegar o ID do curso que o usuário selecionou
    var idCurso = document.getElementById('selCurso').value
    var url = "/LPW/crud_alunos_ajax/api/disciplinas/listByCurso.php?id=" + idCurso

    //Pegar o select com as disciplinas
    var selDisciplina = document.getElementById('selDisciplina')
    selDisciplina.innerHTML = '';
    criarOption(selDisciplina, 0, '--Selecione--', 0)
 
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", url, true);
    xhttp.onload = function(){
        var resposta = xhttp.responseText;

        //Converter JSON (texto) para objeto Javascript
        var disciplinas = JSON.parse(resposta);
        for(var i = 0; i<disciplinas.length;i++){
            var disc = disciplinas[i]
            criarOption(selDisciplina, disc['id'], disc['codigo'] + ' - ' + disc['nome'], 0)
            /*console.log(disc['id'] + ' - ' + disc['nome'] + ' - ' + disc['codigo'])*/
        }
        //console.log(resposta)
    }
    //console.log("Passou")
    xhttp.send();
    
}

//Função para carregar as disciplinas do curso (Forma síncrona)
function carregarDisciplinasSincrono(){
    //Pegar o ID do curso que o usuário selecionou
    var idCurso = document.getElementById('selCurso').value
    var url = "/LPW/crud_alunos_ajax/api/disciplinas/listByCurso.php?id=" + idCurso

    //Pegar o select com as disciplinas
    var selDisciplina = document.getElementById('selDisciplina')
    selDisciplina.innerHTML = '';
    criarOption(selDisciplina, 0, '--Selecione--', 0)
 
    var xhttp = new XMLHttpRequest();
    xhttp.open("GET", url, false);
    xhttp.send();
    var resposta = xhttp.responseText;
    
    //Converter JSON (texto) para objeto Javascript
    var disciplinas = JSON.parse(resposta);
    for(var i = 0; i<disciplinas.length;i++){
        var disc = disciplinas[i]
        criarOption(selDisciplina, disc['id'], disc['codigo'] + ' - ' + disc['nome'], 0)
        /*console.log(disc['id'] + ' - ' + disc['nome'] + ' - ' + disc['codigo'])*/
    }
}

//FunçãocriarOption -> será chamada durante a implementação
function criarOption(elem, value, label, valueSelected) {
    var option = document.createElement('option');
    option.setAttribute("value", value);
    option.innerHTML = label;

    if(value == valueSelected)
        option.selected = true;
    
    elem.appendChild(option);
}

function salvarTurma(){
    //Capturar os dados preenchidos no formulário
    var ano = document.getElementById('txtAno').value;
    var curso = document.getElementById('selCurso').value;
    var disciplina = document.getElementById('selDisciplina').value;

    //Criar o objeto FormData
    var dados = new FormData();
    dados.append('ano', ano);
    dados.append('idCurso', curso);
    dados.append('idDisciplina', disciplina);

    //Criar a requisição AJAX
    var url = "/LPW/crud_alunos_ajax/api/turmas/insertTurmas.php";
    var xhttp = new XMLHttpRequest();
    xhttp.open('POST', url); //Assíncrono
    xhttp.onload = function(){
        var resposta = xhttp.responseText;

        console.log(resposta);
    }
    //Enviar a requisição
    xhttp.send(dados);
}